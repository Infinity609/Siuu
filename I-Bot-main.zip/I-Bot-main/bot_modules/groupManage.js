const { getMessageData } = require("./helper");
const DbOperation = require("../Db/dbOperation.js");
class groupManage {
    static async tagAll(sock, chatId, messageData, msg, isAdmins) {
        try {
            const grpMembers = await sock.groupMetadata(chatId);
            const list = [];
            let text = "";
            for (let i = 0; i < grpMembers.participants.length; i++) {
                if (isAdmins) {
                    if (grpMembers.participants[i].admin) {
                        text =
                            text +
                            `@${grpMembers.participants[i].id.replace(
                "@s.whatsapp.net",
                ""
              )} `;
                        list.push(grpMembers.participants[i].id);
                    }
                } else {
                    text =
                        text +
                        `@${grpMembers.participants[i].id.replace("@s.whatsapp.net", "")} `;
                    list.push(grpMembers.participants[i].id);
                }
            }
            console.log(messageData);
            if (messageData.msgType === "conversation") {
                text = `${msg.pushName} has tagged all of you:\n\n${messageData.msgText}\n ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​${text}`;
                await sock.sendMessage(chatId, {
                    text: text,
                    mentions: list,
                });
            } else if (messageData.msgType === "reply") {
                let extraText;
                try {
                    extraText = messageData.quotedMessage.quotedMessage.conversation ?
                        messageData.quotedMessage.quotedMessage.conversation :
                        messageData.quotedMessage.quotedMessage.extendedTextMessage.text;
                } catch (err) {
                    extraText = "";
                }
                text = `${msg.pushName} has tagged all of you:\n\n${extraText.replace(
          "#tagall",
          ""
        )}\n ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​${text}`;
                await sock.sendMessage(
                    chatId, {
                        text: text,
                        mentions: list,
                    }, { quoted: msg }
                );
            }
        } catch (err) {
            console.log("Tag members error: ", err);
        }
    }
    static async add(sock, chatId, list, senderId, msg) {
        let reply = "";
        const grpMembers = await sock.groupMetadata(chatId);
        const grpAdminList = [];
        const grpMemberList = [];
        let chkCatch = 0;
        let i;
        for (i = 0; i < grpMembers.participants.length; i++) {
            if (grpMembers.participants[i].admin) {
                grpAdminList.push(grpMembers.participants[i].id);
            }
            grpMemberList.push(grpMembers.participants[i].id);
        }
        console.log(grpMemberList);
        console.log(grpAdminList);
        console.log("yyyyyyyyyyyyyyyyyyy", grpAdminList, senderId);

        console.log(grpAdminList.find((id) => id === senderId));
        if (grpAdminList.find((id) => id === senderId)) {
            if (!grpMemberList.find((id) => id === list[0])) {
                const response = await sock
                    .groupParticipantsUpdate(
                        chatId,
                        list,
                        "add" // replace this parameter with "remove", "demote" or "promote"
                    );
                const res=response[0].status;
                if(res==='403'){
                    await sock.sendMessage(chatId,{text:`_❌ Number has privacy on adding group!_`},{quoted:msg});
                    return;
                }    
                if(res==='408'){
                    await sock.sendMessage(chatId,{text:`_❌ Number has left the group recently!_`},{quoted:msg});
                    return;
                }
                if(res==='500'){
                    await sock.sendMessage(chatId,{text:`_❌ Group is currently full!_`},{quoted:msg});
                    return;
                }
                return response;
                console.log(response, "97y793y94");
                if (!chkCatch) {
                    console.log(JSON.stringify(response, undefined, 2), "141525363764");
                }
                reply = `Number added to the group`;
            } else {
                reply = "Number already exist";
            }
        } else {
            reply = "Command only for admins";
        }

        await sock.sendMessage(chatId, { text: reply }, { quoted: msg });
        console.log("adding numb");
        //        console.log(response, "67676");
    }

    static async remove(sock, chatId, list, senderId, msg) {
        let reply = "";
        const grpMembers = await sock.groupMetadata(chatId);
        const grpAdminList = [];
        const grpMemberList = [];
        let i;
        for (i = 0; i < grpMembers.participants.length; i++) {
            if (grpMembers.participants[i].admin) {
                grpAdminList.push(grpMembers.participants[i].id);
            }
            grpMemberList.push(grpMembers.participants[i].id);
        }
        console.log(grpAdminList, senderId);
        if (grpAdminList.find((id) => id === senderId)) {
            if (grpMemberList.find((id) => id === list[0])) {
                const response = await sock.groupParticipantsUpdate(
                    chatId,
                    list,
                    "remove" // replace this parameter with "remove", "demote" or "promote"
                );
                const res=response[0].status;
                if(res==='406'){
                    await sock.sendMessage(chatId,{text:`Group owner cannot be removed!`},{quoted:msg});
                    return;
                }
                if(res==='200')
                reply = `Number removed from the group`;
                else
                    reply=`Number couldn't be removed`;
            } else {
                reply = "Number not in the group";
            }
        } else {
            reply = "Command only for admins";
        }

        await sock.sendMessage(chatId, { text: reply });
    }

    static editGroupDesc() {}
    static changeGroupDp() {}
    static async demote(sock, chatId, list, senderId, msg) {
        let reply = "";
        const grpMembers = await sock.groupMetadata(chatId);
        console.log(JSON.stringify(grpMembers, undefined, 2));
        const grpAdminList = [];
        const grpMemberList = [];
        let chkCatch = 0;
        let i;
        for (i = 0; i < grpMembers.participants.length; i++) {
            if (grpMembers.participants[i].admin) {
                grpAdminList.push(grpMembers.participants[i].id);
            }
            grpMemberList.push(grpMembers.participants[i].id);
        }
        console.log(grpMemberList);
        console.log(grpAdminList);
        console.log(grpAdminList.find((id) => id === senderId));
        if (grpAdminList.find((id) => id === senderId)) {
            if (grpMemberList.find((id) => id === list[0])) {
                if (grpAdminList.find((id) => id === list[0])) {
                    const response = await sock.groupParticipantsUpdate(
                        chatId,
                        list,
                        "demote" // replace this parameter with "remove", "demote" or "promote"
                    );
                    reply = "Number demoted";
                } else {
                    reply = "Number is not an admin!";
                }
            } else {
                reply = "Number not in the group";
            }
        } else {
            reply = "Command only for admins";
        }

        await sock.sendMessage(chatId, { text: reply }, { quoted: msg });
    }
    static async promote(sock, chatId, list, senderId, msg) {
        let reply = "";
        const grpMembers = await sock.groupMetadata(chatId);
        console.log(JSON.stringify(grpMembers, undefined, 2));
        const grpAdminList = [];
        const grpMemberList = [];
        let chkCatch = 0;
        let i;
        for (i = 0; i < grpMembers.participants.length; i++) {
            if (grpMembers.participants[i].admin) {
                grpAdminList.push(grpMembers.participants[i].id);
            }
            grpMemberList.push(grpMembers.participants[i].id);
        }
        console.log(grpMemberList);
        console.log(grpAdminList);
        console.log(grpAdminList.find((id) => id === senderId));
        if (grpAdminList.find((id) => id === senderId)) {
            if (grpMemberList.find((id) => id === list[0])) {
                if (!grpAdminList.find((id) => id === list[0])) {
                    const response = await sock.groupParticipantsUpdate(
                        chatId,
                        list,
                        "promote" // replace this parameter with "remove", "demote" or "promote"
                    );
                    reply = "Number promoted";
                } else {
                    reply = "Number is already an admin!";
                }
            } else {
                reply = "Number not in the group";
            }
        } else {
            reply = "Command only for admins";
        }

        await sock.sendMessage(chatId, { text: reply }, { quoted: msg });
    }
    static async groupSetting(sock, chatId, senderId,state) {
        let reply = "";
        const grpMembers = await sock.groupMetadata(chatId);
        const grpAdminList = [];
        let i;
        for (i = 0; i < grpMembers.participants.length; i++) {
            if (grpMembers.participants[i].admin) {
                grpAdminList.push(grpMembers.participants[i].id);
            }
        }
        if (grpAdminList.find((id) => id === senderId)) {
            if(state==0){
            // only allow admins to send messages
            await sock.groupSettingUpdate(chatId, "announcement");
            }
            if(state==1){
            // allow everyone to send messages
            await sock.groupSettingUpdate(chatId, "not_announcement");
            }
        } else {
            await sock.sendMessage(chatId,{text:'Admin ban pehle lamde'},{quoted:msg});
        }

        // // allow everyone to modify the group's settings -- like display picture etc.
        // await sock.groupSettingUpdate(chatId, "unlocked");
        // // only allow admins to modify the group's settings
        // await sock.groupSettingUpdate(chatId, "locked");
    }
    static async getLink(sock, chatId, senderId, msg) {
        let reply = "";
        const grpMembers = await sock.groupMetadata(chatId);
        const grpAdminList = [];
        let i;
        for (i = 0; i < grpMembers.participants.length; i++) {
            if (grpMembers.participants[i].admin) {
                grpAdminList.push(grpMembers.participants[i].id);
            }
        }
        if (grpAdminList.find((id) => id === senderId)) {
            const code = await sock.groupInviteCode(chatId);
            console.log("invite link",code);
            reply = `https://chat.whatsapp.com/${code}`;
        } else {
            reply = "You are not an Admin!";
        }
        // const templateButtons = [
        //     {buttonId:1,urlButton:{displayText:'Link',url:reply}},
        // ];
        // const templateMessage = {
        //     text: "Link",
        //     linkPreview:true,
        //     footer: `❤️${grpMembers.subject} Link`,
        //     templateButtons: templateButtons,
        // };
        const groupLink=`*${grpMembers.subject} Link* ❤️ \n${reply}`
        //await sock.sendMessage(chatId, templateMessage);
        await sock.sendMessage(chatId,{
                                 text:groupLink,
                                 linkPreview:true    
                                },
                                {quoted:msg});
    }

    static async botOnOff(sock, chatId, msg, on) {
        try {
            if (on) {
                if (await DbOperation.checkOn(chatId)) {
                    await sock.sendMessage(
                        chatId, { text: "I am already active sir/mam!\nUse #help for menu" }, { quoted: msg }
                    );
                } else {
                    if (await DbOperation.turnOnOff(chatId, 1)) {
                        await sock.sendMessage(
                            chatId, { text: "Bot is now active!" }, { quoted: msg }
                        );
                    } else {
                        await sock.sendMessage(
                            chatId, { text: "Some Error Occured! Try again later" }, { quoted: msg }
                        );
                    }
                }
            } else {
                if (await DbOperation.checkOn(chatId)) {
                    if (await DbOperation.turnOnOff(chatId, 0)) {
                        await sock.sendMessage(
                            chatId, { text: "Bot is now inactive!" }, { quoted: msg }
                        );
                    } else {
                        await sock.sendMessage(
                            chatId, { text: "Some Error Occured! Try again later" }, { quoted: msg }
                        );
                    }
                } else {
                    await sock.sendMessage(
                        chatId, { text: "I am already inactive sir/mam!" }, { quoted: msg }
                    );
                }
            }
        } catch (err) {
            console.log("Error turning bot on/off", err);
        }
    }
}
module.exports = groupManage;