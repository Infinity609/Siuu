while true
do
echo "Restarting..."
node main.js
done